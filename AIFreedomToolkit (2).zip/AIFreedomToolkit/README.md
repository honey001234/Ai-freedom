# TermuxAI

A Termux-compatible Python application for customizing and running open source AI models with flexible configuration options.

## Overview

TermuxAI allows you to download, customize, and run open source AI language models directly on your Android device using Termux. The application provides both a command-line interface (CLI) and a web interface for easy interaction.

## Features

- **Download Models**: Fetch models from Hugging Face Hub with a simple command
- **Customize Inference**: Adjust parameters like temperature, top-p, top-k, etc.
- **Combine Models**: Merge two or more models using different combination methods
- **Web Interface**: Chat with AI models through a browser-based UI
- **Command Line**: Full CLI functionality for terminal users
- **Memory Optimization**: Auto-detects available resources and optimizes accordingly
- **Fallback Support**: Works with partial dependencies for flexibility in constrained environments

## Installation

1. Install Termux from F-Droid or Google Play Store
2. Install Python in Termux:
   ```bash
   pkg install python
   ```
3. Install TermuxAI:
   ```bash
   pip install termuxai
   ```

## Usage

### Web Interface

Start the web server:
```bash
python run.py
```

Then open http://localhost:5000 in your browser.

### Command Line

List downloaded models:
```bash
python cli_main.py list
```

Download a model:
```bash
python cli_main.py download <model_name>
```

Chat with a model:
Combine two or more models:
```bash
python cli_main.py combine --models model1 model2 --output combined_model --method weighted_average
```

```bash
python cli_main.py run <model_name> --interactive
```

## Configuration

Configuration is stored in `~/.config/termuxai/config.json`. You can edit this file manually or use the config page in the web interface.

## Requirements

See [requirements.md](requirements.md) for detailed dependency information.

## Troubleshooting

- If AI dependencies fail to install, the application will still function with limited capabilities
- For memory errors, try smaller models or adjust the memory limit in the configuration
- If experiencing crashes, check system resources with `top` command

## License

MIT License