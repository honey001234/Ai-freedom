#!/usr/bin/env python3
"""
TermuxAI CLI entry point.
This allows users to interact with TermuxAI through the command line.
"""

from termuxai.cli import cli

if __name__ == "__main__":
    cli()