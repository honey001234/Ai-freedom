#!/usr/bin/env python3
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session
import os
import json
import logging
from pathlib import Path
from termuxai.config import Config
from termuxai.model_manager import ModelManager
from termuxai.downloader import ModelDownloader
from termuxai.inference import ModelInference
from termuxai.utils import get_available_memory, check_termux_environment

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Create Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "termuxai-secret-key")

# Initialize TermuxAI components
config = Config()
manager = ModelManager(config)
downloader = ModelDownloader(config)

# Keep track of loaded models
inference_engines = {}

@app.route('/')
def index():
    """Homepage showing available models and download option."""
    # Get list of downloaded models
    models = manager.list_downloaded_models()
    
    # Get available memory for display
    available_mem = get_available_memory()
    
    # Check if running in Termux
    is_termux = check_termux_environment()
    
    return render_template('index.html', 
                          models=models, 
                          available_memory=f"{available_mem:.2f} GB",
                          is_termux=is_termux)

@app.route('/models')
def list_models():
    """List all downloaded models."""
    models = manager.list_downloaded_models()
    return render_template('models.html', models=models)

@app.route('/download', methods=['GET', 'POST'])
def download_model():
    """Download a model from Hugging Face."""
    if request.method == 'POST':
        model_name = request.form.get('model_name')
        quantized = 'quantized' in request.form
        force = 'force' in request.form
        
        if not model_name:
            flash('Please enter a model name', 'danger')
            return redirect(url_for('download_model'))
        
        # Check memory requirements
        available_mem = get_available_memory()
        if not downloader.check_model_memory_requirements(model_name, available_mem):
            flash(f'Warning: The model might be too large for your device (Available: {available_mem:.2f} GB)', 'warning')
            # Continue anyway if the user submitted the form
        
        try:
            # Download the model
            model_path = downloader.download_model(
                model_name=model_name,
                quantized=quantized,
                force=force
            )
            
            if model_path:
                flash(f'Successfully downloaded model: {model_name}', 'success')
            else:
                flash(f'Failed to download model: {model_name}', 'danger')
                
        except Exception as e:
            flash(f'Error downloading model: {str(e)}', 'danger')
        
        return redirect(url_for('list_models'))
    
    return render_template('download.html')

@app.route('/remove/<model_name>', methods=['POST'])
def remove_model(model_name):
    """Remove a downloaded model."""
    try:
        # Unload model if it's loaded
        if model_name in inference_engines:
            inference_engines[model_name].unload_model()
            del inference_engines[model_name]
        
        success = manager.remove_model(model_name)
        if success:
            flash(f'Successfully removed model: {model_name}', 'success')
        else:
            flash(f'Failed to remove model: {model_name}', 'danger')
    except Exception as e:
        flash(f'Error removing model: {str(e)}', 'danger')
    
    return redirect(url_for('list_models'))

@app.route('/chat/<model_name>', methods=['GET', 'POST'])
def chat(model_name):
    """Chat interface for interacting with a model."""
    # Check if model exists
    if not manager.is_model_downloaded(model_name):
        flash(f'Model not found: {model_name}', 'danger')
        return redirect(url_for('list_models'))
    
    # Check for required dependencies
    import importlib
    has_transformers = importlib.util.find_spec("transformers") is not None
    has_torch = importlib.util.find_spec("torch") is not None
    
    # Initialize chat history in session if needed
    if 'chat_history' not in session:
        session['chat_history'] = {}
    if model_name not in session['chat_history']:
        session['chat_history'][model_name] = []
    
    # Load model settings from session or use defaults
    if 'model_settings' not in session:
        session['model_settings'] = {}
    if model_name not in session['model_settings']:
        session['model_settings'][model_name] = {
            'temperature': 0.7,
            'max_length': 1024,
            'top_p': 0.9,
            'top_k': 40,
            'repetition_penalty': 1.1
        }
    
    # Process chat message if this is a POST request
    if request.method == 'POST':
        user_message = request.form.get('message', '').strip()
        
        if user_message:
            # Add user message to history
            session['chat_history'][model_name].append({
                'role': 'user',
                'content': user_message
            })
            
            # Check for required dependencies before attempting to load or run the model
            if not has_transformers:
                # Add placeholder AI response explaining the missing dependency
                session['chat_history'][model_name].append({
                    'role': 'assistant',
                    'content': "I cannot generate a response because the required 'transformers' package is not installed. This is an educational tool that simulates AI model capabilities. To use real AI models, please install the transformers package and its dependencies in your environment."
                })
                flash('Missing required dependency: transformers package. This is a simulation mode.', 'warning')
                session.modified = True
                return redirect(url_for('chat', model_name=model_name))
                
            if not has_torch:
                # Add placeholder AI response explaining the missing dependency
                session['chat_history'][model_name].append({
                    'role': 'assistant',
                    'content': "I cannot generate a response because the required 'torch' package is not installed. This is an educational tool that simulates AI model capabilities. To use real AI models, please install PyTorch and its dependencies in your environment."
                })
                flash('Missing required dependency: torch package. This is a simulation mode.', 'warning')
                session.modified = True
                return redirect(url_for('chat', model_name=model_name))
            
            # Get model settings
            settings = session['model_settings'][model_name]
            
            try:
                # Load model if not already loaded
                if model_name not in inference_engines:
                    inference_engines[model_name] = ModelInference(config)
                    # Use 80% of available memory
                    available_mem = get_available_memory()
                    memory_limit = int(available_mem * 0.8 * 1024)  # Convert to MB
                    success = inference_engines[model_name].load_model(model_name, memory_limit=memory_limit)
                    
                    if not success:
                        # Model loading failed, add an explanation message
                        error_msg = "Failed to load the model. This could be due to missing dependencies or insufficient resources. This is an educational tool that demonstrates AI model concepts."
                        session['chat_history'][model_name].append({
                            'role': 'assistant',
                            'content': error_msg
                        })
                        session.modified = True
                        flash('Failed to load model. Using simulation mode.', 'warning')
                        return redirect(url_for('chat', model_name=model_name))
                
                # Generate response
                generation_config = {
                    'temperature': float(settings['temperature']),
                    'max_length': int(settings['max_length']),
                    'top_p': float(settings['top_p']),
                    'top_k': int(settings['top_k']),
                    'repetition_penalty': float(settings['repetition_penalty'])
                }
                
                ai_response = inference_engines[model_name].generate(user_message, generation_config)
                
                # Check if the response is an error message
                if ai_response.startswith("Error:"):
                    # Add a more user-friendly explanation
                    ai_response = f"{ai_response}\n\nThis is an educational tool that demonstrates AI model concepts. For full functionality, please ensure all required dependencies are installed."
                
                # Add AI response to history
                session['chat_history'][model_name].append({
                    'role': 'assistant',
                    'content': ai_response
                })
                
                # Save session
                session.modified = True
                
            except Exception as e:
                error_msg = f"An error occurred: {str(e)}\n\nThis is an educational tool that demonstrates AI model concepts."
                session['chat_history'][model_name].append({
                    'role': 'assistant',
                    'content': error_msg
                })
                session.modified = True
                flash(f'Error: {str(e)}. Using simulation mode.', 'warning')
                logger.error(f"Error generating response: {e}")
        
        # Redirect to refresh the page (avoid form resubmission)
        return redirect(url_for('chat', model_name=model_name))
    
    # Add a warning if dependencies are missing
    if not has_transformers or not has_torch:
        missing_deps = []
        if not has_transformers:
            missing_deps.append("transformers")
        if not has_torch:
            missing_deps.append("torch")
        flash(f"Missing dependencies: {', '.join(missing_deps)}. Running in simulation mode.", 'warning')
    
    return render_template('chat.html', 
                          model_name=model_name,
                          chat_history=session['chat_history'].get(model_name, []),
                          settings=session['model_settings'].get(model_name, {}),
                          simulation_mode=(not has_transformers or not has_torch))

@app.route('/settings/<model_name>', methods=['GET', 'POST'])
def model_settings(model_name):
    """Update model settings."""
    # Check if model exists
    if not manager.is_model_downloaded(model_name):
        flash(f'Model not found: {model_name}', 'danger')
        return redirect(url_for('list_models'))
    
    # Initialize settings in session if needed
    if 'model_settings' not in session:
        session['model_settings'] = {}
    if model_name not in session['model_settings']:
        session['model_settings'][model_name] = {
            'temperature': 0.7,
            'max_length': 1024,
            'top_p': 0.9,
            'top_k': 40,
            'repetition_penalty': 1.1
        }
    
    if request.method == 'POST':
        # Update settings
        try:
            session['model_settings'][model_name] = {
                'temperature': float(request.form.get('temperature', 0.7)),
                'max_length': int(request.form.get('max_length', 1024)),
                'top_p': float(request.form.get('top_p', 0.9)),
                'top_k': int(request.form.get('top_k', 40)),
                'repetition_penalty': float(request.form.get('repetition_penalty', 1.1))
            }
            session.modified = True
            flash('Settings updated successfully', 'success')
        except Exception as e:
            flash(f'Error updating settings: {str(e)}', 'danger')
        
        return redirect(url_for('chat', model_name=model_name))
    
    return render_template('settings.html', 
                          model_name=model_name,
                          settings=session['model_settings'][model_name])

@app.route('/clear_chat/<model_name>', methods=['POST'])
def clear_chat(model_name):
    """Clear chat history for a model."""
    if 'chat_history' in session and model_name in session['chat_history']:
        session['chat_history'][model_name] = []
        session.modified = True
        flash('Chat history cleared', 'success')
    
    return redirect(url_for('chat', model_name=model_name))

@app.route('/unload/<model_name>', methods=['POST'])
def unload_model(model_name):
    """Unload a model from memory."""
    if model_name in inference_engines:
        try:
            inference_engines[model_name].unload_model()
            del inference_engines[model_name]
            flash(f'Model unloaded: {model_name}', 'success')
        except Exception as e:
            flash(f'Error unloading model: {str(e)}', 'danger')
    
    return redirect(url_for('list_models'))

@app.route('/combine', methods=['GET', 'POST'])
def combine_models():
    """Combine two or more models into a new model."""
    # Get list of available models
    available_models = manager.list_downloaded_models()
    
    if request.method == 'POST':
        try:
            # Get form data
            combined_name = request.form.get('combined_name', '').strip()
            selected_models = request.form.getlist('selected_models')
            combination_method = request.form.get('combination_method', 'weighted_average')
            
            # Validation
            if not combined_name:
                flash('Please provide a name for the combined model', 'danger')
                return redirect(url_for('combine_models'))
                
            if len(selected_models) < 2:
                flash('Please select at least two models to combine', 'danger')
                return redirect(url_for('combine_models'))
            
            # Get weights for each model
            weights = []
            for model_name in selected_models:
                weight_value = float(request.form.get(f'weight_{model_name}', 50)) / 100.0
                weights.append(weight_value)
            
            # Normalize weights
            sum_weights = sum(weights)
            if sum_weights > 0:
                weights = [w / sum_weights for w in weights]
            else:
                # Default to equal weights if all were zero
                weights = [1.0 / len(selected_models)] * len(selected_models)
            
            # Perform model combination
            success = manager.combine_models(
                model_names=selected_models,
                combined_name=combined_name,
                weights=weights,
                method=combination_method
            )
            
            if success:
                # Check if combined model is a placeholder due to missing dependencies
                combined_path = config.get_models_dir() / combined_name
                is_placeholder = False
                if (combined_path / "README.md").exists():
                    with open(combined_path / "README.md", 'r') as f:
                        if "placeholder" in f.read().lower():
                            is_placeholder = True
                
                if is_placeholder:
                    flash(f'Created placeholder for combined model: {combined_name}. Install required dependencies to create an actual combined model.', 'warning')
                else:
                    flash(f'Successfully created combined model: {combined_name}', 'success')
                return redirect(url_for('list_models'))
            else:
                flash('Failed to combine models. Check logs for details.', 'danger')
                
        except Exception as e:
            logger.error(f"Error combining models: {e}")
            flash(f'Error combining models: {str(e)}', 'danger')
    
    return render_template('combine.html', available_models=available_models)

@app.route('/config', methods=['GET', 'POST'])
def config_page():
    """Configuration settings page."""
    if request.method == 'POST':
        # Update configuration
        try:
            new_config = {
                'models_dir': request.form.get('models_dir', config.get('models_dir')),
                'max_memory_usage': int(request.form.get('max_memory_usage', 80)),
                'default_temperature': float(request.form.get('default_temperature', 0.7)),
                'default_max_length': int(request.form.get('default_max_length', 1024)),
                'default_top_p': float(request.form.get('default_top_p', 0.9)),
                'default_top_k': int(request.form.get('default_top_k', 40)),
                'default_repetition_penalty': float(request.form.get('default_repetition_penalty', 1.1)),
                'use_onnx': 'use_onnx' in request.form
            }
            
            # Save configuration
            config.save_config(new_config)
            flash('Configuration updated successfully', 'success')
        except Exception as e:
            flash(f'Error updating configuration: {str(e)}', 'danger')
        
        return redirect(url_for('config_page'))
    
    # Get current configuration
    current_config = config.load_config()
    
    return render_template('config.html', config=current_config)

@app.route('/api/models', methods=['GET'])
def api_list_models():
    """API endpoint to list models."""
    models = manager.list_downloaded_models()
    return jsonify(models)

@app.route('/api/generate', methods=['POST'])
def api_generate():
    """API endpoint for text generation."""
    data = request.json
    
    if not data:
        return jsonify({'error': 'No data provided'}), 400
    
    model_name = data.get('model')
    prompt = data.get('prompt')
    
    if not model_name or not prompt:
        return jsonify({'error': 'Model name and prompt are required'}), 400
    
    # Check if model exists
    if not manager.is_model_downloaded(model_name):
        return jsonify({'error': f'Model not found: {model_name}'}), 404
    
    try:
        # Load model if not already loaded
        if model_name not in inference_engines:
            inference_engines[model_name] = ModelInference(config)
            available_mem = get_available_memory()
            memory_limit = int(available_mem * 0.8 * 1024)
            inference_engines[model_name].load_model(model_name, memory_limit=memory_limit)
        
        # Get generation config from request or use defaults
        generation_config = {
            'temperature': float(data.get('temperature', 0.7)),
            'max_length': int(data.get('max_length', 1024)),
            'top_p': float(data.get('top_p', 0.9)),
            'top_k': int(data.get('top_k', 40)),
            'repetition_penalty': float(data.get('repetition_penalty', 1.1))
        }
        
        # Generate response
        response = inference_engines[model_name].generate(prompt, generation_config)
        
        return jsonify({'response': response})
    
    except Exception as e:
        logger.error(f"API generation error: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/is_termux', methods=['GET'])
def api_is_termux():
    """API endpoint to check if running in Termux environment."""
    is_termux = check_termux_environment()
    return jsonify({'is_termux': is_termux})

# Shutdown hook to clean up models
@app.teardown_appcontext
def shutdown_cleanup(exception=None):
    """Clean up resources when the app shuts down."""
    for model_name, engine in list(inference_engines.items()):
        try:
            engine.unload_model()
        except:
            pass
    inference_engines.clear()

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)