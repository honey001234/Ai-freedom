# TermuxAI Requirements

## Core Dependencies
- Python 3.8+
- Flask
- SQLAlchemy
- psutil
- requests
- Rich (for CLI formatting)
- tqdm (for download progress)
- click (for CLI commands)

## Optional AI Dependencies
These are needed for full AI model functionality but are optional for the base application:

- PyTorch
- Transformers (from Hugging Face)
- ONNX Runtime (for optimized inference)
- Hugging Face Hub
- bitsandbytes (for model quantization)

## System Requirements
- At least 2GB available RAM for small models
- 4GB+ RAM recommended for medium-sized models
- Storage: 1GB+ for the application and each model
- Android device running Termux with Python support

## Installation Notes for Termux

1. Install core dependencies:
```bash
pip install flask sqlalchemy psutil requests rich tqdm click
```

2. Attempt to install AI dependencies (not all may succeed in Termux environment):
```bash
pip install torch torchvision --extra-index-url https://download.pytorch.org/whl/cpu
pip install transformers onnxruntime huggingface_hub
```

3. The application will gracefully handle missing AI dependencies

## Configuration Requirements
- Configuration stored in user's home directory under `.config/termuxai`
- Model storage location configurable (defaults to `.local/share/termuxai/models`)
- Customizable inference parameters (temperature, max length, etc.)
- Ability to run in desktop/server mode or Termux mode