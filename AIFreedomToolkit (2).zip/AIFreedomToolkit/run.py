#!/usr/bin/env python3
"""
TermuxAI Web Interface runner script.
This script starts the Flask web application for TermuxAI.
"""
import logging
import os
import sys
from pathlib import Path

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

# Ensure the app can find the modules
current_dir = Path(__file__).parent
if str(current_dir) not in sys.path:
    sys.path.append(str(current_dir))

try:
    # Import the Flask application
    from main import app
    from termuxai.utils import check_termux_environment, get_available_memory
    
    # Display environment information
    logger = logging.getLogger(__name__)
    is_termux = check_termux_environment()
    avail_mem = get_available_memory()
    
    logger.info(f"Starting TermuxAI web interface")
    logger.info(f"Running in Termux environment: {is_termux}")
    logger.info(f"Available memory: {avail_mem:.2f} GB")
    
    # Check if we're running with minimal dependencies
    try:
        import torch
        import transformers
        logger.info("Full AI dependencies available")
    except ImportError:
        logger.warning("Running with minimal dependencies - some features may be limited")
    
    # Run the Flask app
    if __name__ == "__main__":
        # Set host to 0.0.0.0 to make it accessible from other devices on the network
        app.run(host="0.0.0.0", port=5000, debug=True)
        
except Exception as e:
    logging.error(f"Error starting TermuxAI: {e}")
    sys.exit(1)