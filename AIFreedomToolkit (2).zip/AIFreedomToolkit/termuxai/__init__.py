"""
TermuxAI - A Termux-compatible Python application for running and customizing open source AI models
"""

__version__ = "0.1.0"
