import os
import click
import logging
from typing import Optional
from rich.console import Console
from rich.progress import Progress, TextColumn, BarColumn, DownloadColumn, TransferSpeedColumn, TimeRemainingColumn
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from .config import Config, DEFAULT_CONFIG
from .downloader import ModelDownloader
from .model_manager import ModelManager
from .inference import ModelInference
from .utils import check_termux_environment, get_available_memory, set_logging_level

console = Console()

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger("termuxai")

@click.group()
@click.version_option()
@click.option("--verbose", "-v", is_flag=True, help="Enable verbose output")
def cli(verbose):
    """TermuxAI: Run and customize open source AI models in Termux."""
    if verbose:
        set_logging_level(logging.DEBUG)
    else:
        set_logging_level(logging.INFO)
    
    # Check if running in Termux environment
    is_termux = check_termux_environment()
    if is_termux:
        logger.debug("Running in Termux environment")
    else:
        logger.warning("Not running in Termux environment. Some features might not work correctly.")

@cli.command()
@click.option("--model", "-m", required=True, help="Model name or ID from Hugging Face")
@click.option("--quantized", "-q", is_flag=True, help="Download quantized version if available")
@click.option("--force", "-f", is_flag=True, help="Force re-download if model already exists")
def download(model: str, quantized: bool, force: bool):
    """Download an AI model from Hugging Face."""
    config = Config()
    downloader = ModelDownloader(config)
    
    console.print(Panel(f"[bold blue]Downloading model:[/] [green]{model}[/]", title="TermuxAI"))
    
    # Get available memory
    available_mem = get_available_memory()
    console.print(f"Available memory: {available_mem:.2f} GB")
    
    # Check if model will fit in memory
    if not downloader.check_model_memory_requirements(model, available_mem):
        console.print("[bold red]Warning:[/] The model might be too large for your device's memory.")
        if not click.confirm("Do you want to continue anyway?", default=False):
            return
    
    with Progress(
        TextColumn("[bold blue]{task.description}"),
        BarColumn(),
        DownloadColumn(),
        TransferSpeedColumn(),
        TimeRemainingColumn(),
        console=console
    ) as progress:
        task = progress.add_task(f"Downloading {model}", total=1000)
        try:
            # Register progress callback
            def update_progress(downloaded, total):
                progress.update(task, completed=int(downloaded * 1000 / total))
            
            model_path = downloader.download_model(
                model_name=model, 
                quantized=quantized, 
                force=force,
                progress_callback=update_progress
            )
            progress.update(task, completed=1000)
            
            if model_path:
                console.print(f"[bold green]Success![/] Model downloaded to: {model_path}")
            else:
                console.print("[bold red]Failed[/] to download the model.")
        except Exception as e:
            console.print(f"[bold red]Error:[/] {str(e)}")

@cli.command()
def list():
    """List all downloaded models."""
    config = Config()
    manager = ModelManager(config)
    
    models = manager.list_downloaded_models()
    
    if not models:
        console.print("[yellow]No models have been downloaded yet.[/]")
        return
    
    table = Table(title="Downloaded Models")
    table.add_column("Name", style="cyan")
    table.add_column("Size", style="green")
    table.add_column("Type", style="blue")
    table.add_column("Date Downloaded", style="magenta")
    
    for model in models:
        table.add_row(
            model["name"],
            model["size"],
            model["type"],
            model["date"]
        )
    
    console.print(table)

@cli.command()
@click.option("--model", "-m", required=True, help="Model name to use")
@click.option("--prompt", "-p", help="Initial prompt for the model")
@click.option("--temperature", "-t", type=float, default=0.7, help="Temperature for sampling")
@click.option("--max-length", "-l", type=int, default=1024, help="Maximum length of the generated text")
@click.option("--top-p", type=float, default=0.9, help="Top-p sampling parameter")
@click.option("--top-k", type=int, default=40, help="Top-k sampling parameter")
@click.option("--repetition-penalty", type=float, default=1.1, help="Repetition penalty")
@click.option("--memory-limit", type=int, help="Memory limit in MB (default: auto-detect)")
@click.option("--interactive", "-i", is_flag=True, help="Run in interactive mode")
def run(model: str, prompt: Optional[str], temperature: float, max_length: int, 
        top_p: float, top_k: int, repetition_penalty: float, memory_limit: Optional[int], 
        interactive: bool):
    """Run AI model with custom parameters."""
    config = Config()
    manager = ModelManager(config)
    
    # Check if model is downloaded
    if not manager.is_model_downloaded(model):
        console.print(f"[bold red]Error:[/] Model '{model}' is not downloaded.")
        if click.confirm("Do you want to download it now?", default=True):
            downloader = ModelDownloader(config)
            downloader.download_model(model)
        else:
            return
    
    # Determine memory limit
    available_mem = get_available_memory()
    if memory_limit is None:
        # Auto-detect: use 80% of available memory
        memory_limit = int(available_mem * 0.8 * 1024)
    
    generation_config = {
        "temperature": temperature,
        "max_length": max_length,
        "top_p": top_p,
        "top_k": top_k,
        "repetition_penalty": repetition_penalty,
    }
    
    inference = ModelInference(config)
    try:
        inference.load_model(model, memory_limit=memory_limit)
        
        if interactive:
            console.print(Panel("[bold green]Interactive Mode[/]\nType your prompts below. Use [bold]/exit[/] to quit.", 
                               title="TermuxAI"))
            while True:
                try:
                    user_prompt = input("\n>>> ")
                    if user_prompt.strip().lower() == "/exit":
                        break
                    
                    with Progress(
                        TextColumn("[bold blue]Generating response..."),
                        BarColumn(),
                        console=console
                    ) as progress:
                        task = progress.add_task("Generating", total=None)
                        response = inference.generate(user_prompt, generation_config)
                    
                    console.print("\n[bold green]AI:[/]")
                    console.print(Text(response.strip()))
                except KeyboardInterrupt:
                    break
                except Exception as e:
                    console.print(f"[bold red]Error:[/] {e}")
        else:
            if not prompt:
                prompt = click.prompt("Enter your prompt")
            
            console.print(f"[bold blue]Prompt:[/] {prompt}")
            console.print("[bold blue]Generating response...[/]")
            
            response = inference.generate(prompt, generation_config)
            console.print("\n[bold green]Response:[/]")
            console.print(Text(response.strip()))
            
    except Exception as e:
        console.print(f"[bold red]Error:[/] {e}")
    finally:
        inference.unload_model()

@cli.command()
@click.option("--model", "-m", help="Model to remove")
@click.option("--all", "-a", is_flag=True, help="Remove all downloaded models")
def remove(model: Optional[str], all: bool):
    """Remove downloaded models."""
    config = Config()
    manager = ModelManager(config)
    
    if all:
        if click.confirm("Are you sure you want to remove ALL downloaded models?", default=False):
            success = manager.remove_all_models()
            if success:
                console.print("[bold green]All models have been removed.[/]")
            else:
                console.print("[bold red]Failed to remove all models.[/]")
        return
    
    if not model:
        console.print("[bold red]Error:[/] Please specify a model to remove or use --all.")
        return
    
    if not manager.is_model_downloaded(model):
        console.print(f"[bold red]Error:[/] Model '{model}' is not downloaded.")
        return
    
    if click.confirm(f"Are you sure you want to remove the model '{model}'?", default=True):
        success = manager.remove_model(model)
        if success:
            console.print(f"[bold green]Model '{model}' has been removed.[/]")
        else:
            console.print(f"[bold red]Failed to remove model '{model}'.[/]")

@cli.command()
@click.option("--models", "-m", required=True, multiple=True, help="Models to combine (can be specified multiple times)")
@click.option("--output", "-o", required=True, help="Name for the combined model")
@click.option("--weights", "-w", multiple=True, type=float, help="Weight for each model (must match number of models)")
@click.option("--method", type=click.Choice(["weighted_average", "task_arithmetic", "layer_selective"], 
                                          case_sensitive=False), 
             default="weighted_average", help="Method for combining models")
def combine(models, output, weights, method):
    """Combine two or more models into a new model."""
    if len(models) < 2:
        console.print("[bold red]Error:[/] At least two models are required for combination.")
        return
        
    config = Config()
    manager = ModelManager(config)
    
    # Validate models exist
    missing_models = []
    for model_name in models:
        if not manager.is_model_downloaded(model_name):
            missing_models.append(model_name)
    
    if missing_models:
        console.print(f"[bold red]Error:[/] The following models are not downloaded: {', '.join(missing_models)}")
        return
    
    # Validate weights if provided
    if weights and len(weights) != len(models):
        console.print("[bold red]Error:[/] Number of weights must match number of models.")
        return
    
    # If weights not provided, use equal weights
    if not weights:
        weights = [1.0 / len(models)] * len(models)
    
    # Normalize weights
    sum_weights = sum(weights)
    normalized_weights = [w / sum_weights for w in weights]
    
    # Display confirmation
    console.print(Panel(f"[bold blue]Combining Models[/]", title="TermuxAI"))
    console.print("Models to combine:")
    for i, (model, weight) in enumerate(zip(models, normalized_weights)):
        console.print(f"  [cyan]{model}[/] with weight [green]{weight:.2f}[/]")
    console.print(f"Output model: [cyan]{output}[/]")
    console.print(f"Method: [cyan]{method}[/]")
    
    if not click.confirm("Proceed with model combination?", default=True):
        return
    
    # Perform combination
    console.print("[bold blue]Combining models...[/]")
    try:
        result = manager.combine_models(
            model_names=list(models),
            combined_name=output,
            weights=normalized_weights,
            method=method
        )
        
        if result:
            console.print(f"[bold green]Success![/] Combined model created as [cyan]{output}[/]")
        else:
            console.print("[bold red]Failed[/] to combine models. Check logs for details.")
    except Exception as e:
        console.print(f"[bold red]Error:[/] {str(e)}")

@cli.command()
@click.option("--create", "-c", is_flag=True, help="Create a new configuration file")
@click.option("--edit", "-e", is_flag=True, help="Edit the configuration file")
@click.option("--show", "-s", is_flag=True, help="Show current configuration")
def config(create: bool, edit: bool, show: bool):
    """Manage configuration settings."""
    config_manager = Config()
    
    if create:
        if os.path.exists(config_manager.config_file):
            if not click.confirm("Configuration file already exists. Overwrite?", default=False):
                return
        
        config_manager.save_config(DEFAULT_CONFIG)
        console.print("[bold green]Configuration file created.[/]")
    
    elif edit:
        # Simple editing through CLI prompts
        current_config = config_manager.load_config()
        
        new_config = {}
        new_config["models_dir"] = click.prompt("Models directory", default=current_config.get("models_dir"))
        new_config["default_model"] = click.prompt("Default model", default=current_config.get("default_model", ""))
        new_config["max_memory_usage"] = click.prompt("Maximum memory usage (%)", 
                                                    default=current_config.get("max_memory_usage", 80), 
                                                    type=int)
        
        config_manager.save_config(new_config)
        console.print("[bold green]Configuration updated.[/]")
    
    elif show:
        current_config = config_manager.load_config()
        
        table = Table(title="Current Configuration")
        table.add_column("Setting", style="cyan")
        table.add_column("Value", style="green")
        
        for key, value in current_config.items():
            table.add_row(key, str(value))
        
        console.print(table)
    
    else:
        console.print("Please specify an option: --create, --edit, or --show")
