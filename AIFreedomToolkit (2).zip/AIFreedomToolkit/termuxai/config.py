import os
import json
import logging
from pathlib import Path

logger = logging.getLogger(__name__)

DEFAULT_CONFIG = {
    "models_dir": os.path.expanduser("~/termuxai_models"),
    "cache_dir": os.path.expanduser("~/.cache/termuxai"),
    "max_memory_usage": 80,  # percentage of available memory
    "default_temperature": 0.7,
    "default_max_length": 1024,
    "default_top_p": 0.9,
    "default_top_k": 40,
    "default_repetition_penalty": 1.1,
    "use_onnx": True,  # Use ONNX Runtime for inference when available
}

class Config:
    """Configuration manager for TermuxAI."""
    
    def __init__(self):
        self.config_dir = os.path.expanduser("~/.config/termuxai")
        self.config_file = os.path.join(self.config_dir, "config.json")
        self._ensure_directories()
        self.config = self.load_config()
    
    def _ensure_directories(self):
        """Ensure that necessary directories exist."""
        dirs = [
            self.config_dir,
            DEFAULT_CONFIG["models_dir"],
            DEFAULT_CONFIG["cache_dir"]
        ]
        
        for directory in dirs:
            os.makedirs(directory, exist_ok=True)
    
    def load_config(self):
        """Load configuration from file or create default if not exists."""
        if not os.path.exists(self.config_file):
            logger.info(f"Configuration file not found. Creating default at {self.config_file}")
            self.save_config(DEFAULT_CONFIG)
            return DEFAULT_CONFIG
        
        try:
            with open(self.config_file, 'r') as f:
                config = json.load(f)
                
            # Merge with defaults for any missing keys
            for key, value in DEFAULT_CONFIG.items():
                if key not in config:
                    config[key] = value
            
            return config
        except Exception as e:
            logger.error(f"Error loading configuration: {e}")
            return DEFAULT_CONFIG
    
    def save_config(self, config):
        """Save configuration to file."""
        try:
            os.makedirs(os.path.dirname(self.config_file), exist_ok=True)
            with open(self.config_file, 'w') as f:
                json.dump(config, f, indent=4)
            return True
        except Exception as e:
            logger.error(f"Error saving configuration: {e}")
            return False
    
    def get(self, key, default=None):
        """Get a configuration value."""
        return self.config.get(key, default)
    
    def set(self, key, value):
        """Set a configuration value and save to file."""
        self.config[key] = value
        return self.save_config(self.config)
    
    def get_models_dir(self):
        """Get the models directory."""
        return Path(self.get("models_dir"))
    
    def get_cache_dir(self):
        """Get the cache directory."""
        return Path(self.get("cache_dir"))
