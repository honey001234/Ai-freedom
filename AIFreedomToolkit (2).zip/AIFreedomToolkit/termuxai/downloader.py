import os
import logging
import requests
import shutil
from pathlib import Path
from typing import Optional, Callable, Dict, Any
from tqdm import tqdm

# Handle optional dependencies - transformers and huggingface_hub might not be installed
try:
    from transformers import AutoTokenizer, AutoModelForCausalLM
    HAVE_TRANSFORMERS = True
except ImportError:
    HAVE_TRANSFORMERS = False

try:
    from huggingface_hub import scan_cache_dir, HfApi, hf_hub_download
    from huggingface_hub.utils import RepositoryNotFoundError, RevisionNotFoundError
    HAVE_HF_HUB = True
except ImportError:
    HAVE_HF_HUB = False

from .config import Config

logger = logging.getLogger(__name__)

class ModelDownloader:
    """Downloads and manages AI models from Hugging Face."""
    
    def __init__(self, config: Config):
        self.config = config
        self.models_dir = config.get_models_dir()
        self.cache_dir = config.get_cache_dir()
        os.makedirs(self.models_dir, exist_ok=True)
        os.makedirs(self.cache_dir, exist_ok=True)
        self.hf_api = None
        if HAVE_HF_HUB:
            self.hf_api = HfApi()
    
    def get_model_info(self, model_name: str) -> Dict[str, Any]:
        """Get information about a model from Hugging Face."""
        if not HAVE_HF_HUB or self.hf_api is None:
            logger.error("huggingface_hub is not installed")
            return {}

        try:
            model_info = self.hf_api.model_info(model_name)
            return {
                "id": model_info.id,
                "sha": model_info.sha,
                "lastModified": model_info.lastModified,
                "tags": model_info.tags,
                "pipeline_tag": model_info.pipeline_tag,
                "siblings": [s.rfilename for s in model_info.siblings]
            }
        except Exception as e:
            logger.error(f"Error getting model info for {model_name}: {e}")
            return {}
    
    def check_model_memory_requirements(self, model_name: str, available_memory_gb: float) -> bool:
        """
        Check if the model's memory requirements are within the available memory.
        Returns True if the model will likely fit, False otherwise.
        """
        if not HAVE_HF_HUB or self.hf_api is None:
            logger.warning("huggingface_hub is not installed, cannot check model memory requirements")
            # Assume it might fit since we can't check
            return True
            
        try:
            model_info = self.get_model_info(model_name)
            
            # Estimate model size from siblings
            total_size_bytes = 0
            for sibling in model_info.get("siblings", []):
                if sibling.endswith(".bin") or sibling.endswith(".safetensors"):
                    # Get file info to determine size
                    try:
                        file_info = self.hf_api.hf_hub_url(model_name, sibling)
                        response = requests.head(file_info)
                        if 'Content-Length' in response.headers:
                            total_size_bytes += int(response.headers['Content-Length'])
                    except Exception as e:
                        logger.warning(f"Could not determine size for {sibling}: {e}")
            
            # Convert to GB
            model_size_gb = total_size_bytes / (1024 ** 3)
            
            # Add overhead (typically 2-3x the model size is needed for inference)
            required_memory_gb = model_size_gb * 3
            
            logger.info(f"Estimated model size: {model_size_gb:.2f} GB")
            logger.info(f"Estimated memory required: {required_memory_gb:.2f} GB")
            logger.info(f"Available memory: {available_memory_gb:.2f} GB")
            
            return required_memory_gb < available_memory_gb
            
        except Exception as e:
            logger.error(f"Error checking model requirements: {e}")
            # If we can't determine, assume it might fit
            return True
    
    def download_model(
        self, 
        model_name: str, 
        quantized: bool = False,
        force: bool = False,
        progress_callback: Optional[Callable[[float, float], None]] = None
    ) -> Optional[Path]:
        """
        Download a model from Hugging Face.
        
        Args:
            model_name: The name of the model on Hugging Face Hub
            quantized: Whether to download a quantized version if available
            force: Whether to force re-download if model already exists
            progress_callback: Callback function for progress updates
            
        Returns:
            Path to the downloaded model directory or None on failure
        """
        model_dir = self.models_dir / model_name
        
        # Check if model already exists
        if model_dir.exists() and not force:
            logger.info(f"Model {model_name} already exists at {model_dir}")
            return model_dir
        
        # Create placeholder for demo purposes if dependencies are missing
        if not HAVE_TRANSFORMERS or not HAVE_HF_HUB:
            logger.error("Missing required dependencies: transformers and/or huggingface_hub")
            
            # Create a mock model directory with explanation
            os.makedirs(model_dir, exist_ok=True)
            
            # Create a README file explaining the requirements
            with open(model_dir / "README.md", "w") as f:
                f.write(f"# {model_name} - Placeholder\n\n")
                f.write("This is a placeholder for a model that would be downloaded from Hugging Face.\n\n")
                f.write("To actually download and use models, you need to install these dependencies:\n")
                f.write("```\npip install torch transformers huggingface_hub\n```\n\n")
                f.write("In Termux, you might need to run:\n")
                f.write("```\npip install --no-deps transformers huggingface_hub\n")
                f.write("pip install torch --extra-index-url https://download.pytorch.org/whl/cpu\n```\n")
            
            # Create a sample config JSON
            with open(model_dir / "config.json", "w") as f:
                f.write('{\n')
                f.write('  "model_type": "placeholder",\n')
                f.write(f'  "model_name": "{model_name}",\n')
                f.write('  "quantized": ' + str(quantized).lower() + ',\n')
                f.write('  "note": "This is a placeholder. Install required dependencies to download real models."\n')
                f.write('}\n')
            
            return model_dir
            
        try:
            logger.info(f"Downloading model {model_name}")
            
            # Create model directory
            os.makedirs(model_dir, exist_ok=True)
            
            if HAVE_TRANSFORMERS:
                try:
                    # Try to get a quantized version first if requested
                    if quantized:
                        try:
                            logger.info("Attempting to download quantized version...")
                            # Look for GGML or GPTQ quantized versions
                            model_name_q = model_name
                            if "-ggml" not in model_name_q and "-gptq" not in model_name_q and "-awq" not in model_name_q:
                                # Try some common quantized model naming patterns
                                for suffix in ["-ggml", "-gptq", "-awq", "-4bit", "-8bit"]:
                                    try:
                                        model_info = self.hf_api.model_info(f"{model_name}{suffix}")
                                        model_name_q = f"{model_name}{suffix}"
                                        logger.info(f"Found quantized version: {model_name_q}")
                                        break
                                    except Exception:
                                        continue
                            
                            if model_name_q != model_name:
                                # Found a quantized version
                                tokenizer = AutoTokenizer.from_pretrained(
                                    model_name_q, 
                                    cache_dir=self.cache_dir,
                                    use_fast=True
                                )
                                model = AutoModelForCausalLM.from_pretrained(
                                    model_name_q,
                                    cache_dir=self.cache_dir,
                                    device_map="auto",
                                    torch_dtype="auto",
                                    low_cpu_mem_usage=True
                                )
                                # Save the model and tokenizer
                                model.save_pretrained(model_dir)
                                tokenizer.save_pretrained(model_dir)
                                return model_dir
                        except Exception as e:
                            logger.warning(f"Could not download quantized version: {e}")
                            logger.info("Falling back to standard model")
                    
                    # Standard model download
                    tokenizer = AutoTokenizer.from_pretrained(
                        model_name, 
                        cache_dir=self.cache_dir,
                        use_fast=True
                    )
                    model = AutoModelForCausalLM.from_pretrained(
                        model_name,
                        cache_dir=self.cache_dir,
                        device_map="auto",
                        torch_dtype="auto",
                        low_cpu_mem_usage=True
                    )
                    
                    # Save the model and tokenizer
                    model.save_pretrained(model_dir)
                    tokenizer.save_pretrained(model_dir)
                    
                    return model_dir
                except Exception as e:
                    logger.error(f"Error downloading model with transformers: {e}")
                    # Fall through to manual download
            
            if HAVE_HF_HUB:
                try:
                    logger.info("Trying manual download with huggingface_hub...")
                    # Get model file list
                    model_info = self.get_model_info(model_name)
                    if not model_info:
                        raise ValueError(f"Could not find model information for {model_name}")
                    
                    files_to_download = []
                    
                    # Add key model files
                    for sibling in model_info.get("siblings", []):
                        if any(sibling.endswith(ext) for ext in ['.bin', '.safetensors', '.json', '.txt', '.py', '.md']):
                            files_to_download.append(sibling)
                    
                    # Download each file
                    for idx, file in enumerate(files_to_download):
                        if progress_callback:
                            progress_callback(idx, len(files_to_download))
                        
                        output_path = model_dir / file
                        os.makedirs(os.path.dirname(output_path), exist_ok=True)
                        
                        try:
                            hf_hub_download(
                                repo_id=model_name,
                                filename=file,
                                local_dir=model_dir,
                                local_dir_use_symlinks=False
                            )
                        except Exception as e:
                            logger.warning(f"Failed to download {file}: {e}")
                    
                    if progress_callback:
                        progress_callback(len(files_to_download), len(files_to_download))
                    
                    return model_dir
                except Exception as e:
                    logger.error(f"Error with manual download: {e}")
            
            # If we got here, both methods failed
            # Clean up the failed download
            if model_dir.exists():
                shutil.rmtree(model_dir)
            return None
            
        except Exception as e:
            logger.error(f"Error downloading model {model_name}: {e}")
            # Clean up any partial downloads
            if model_dir.exists():
                shutil.rmtree(model_dir)
            return None
