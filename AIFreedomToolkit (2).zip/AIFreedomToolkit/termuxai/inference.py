import os
import gc
import logging
import json
from typing import Dict, Any, Optional, List, Union
from pathlib import Path
import psutil

# Handle optional dependencies
try:
    import torch
    HAVE_TORCH = True
except ImportError:
    HAVE_TORCH = False

try:
    from transformers import (
        AutoTokenizer, 
        AutoModelForCausalLM,
        TextIteratorStreamer,
        GenerationConfig
    )
    HAVE_TRANSFORMERS = True
except ImportError:
    HAVE_TRANSFORMERS = False

try:
    import onnxruntime as ort
    ONNX_AVAILABLE = True
except ImportError:
    ONNX_AVAILABLE = False

from .config import Config

logger = logging.getLogger(__name__)

class ModelInference:
    """Handles AI model inference with optimizations for Termux environment."""
    
    def __init__(self, config: Config):
        self.config = config
        self.model = None
        self.tokenizer = None
        self.model_name = None
        self.device = self._get_device()
        self.onnx_session = None
    
    def _get_device(self):
        """Get the appropriate device for inference."""
        if not HAVE_TORCH:
            return "cpu"
            
        if torch.cuda.is_available():
            return torch.device("cuda")
        elif hasattr(torch, 'mps') and torch.backends.mps.is_available():
            return torch.device("mps")
        else:
            return torch.device("cpu")
    
    def load_model(self, model_name: str, memory_limit: Optional[int] = None) -> bool:
        """
        Load a model for inference.
        
        Args:
            model_name: Name of the model to load
            memory_limit: Memory limit in MB (None for auto)
            
        Returns:
            True if loading was successful, False otherwise
        """
        if not HAVE_TRANSFORMERS:
            logger.error("Cannot load model: transformers package is not installed")
            return False
            
        if not HAVE_TORCH:
            logger.error("Cannot load model: torch package is not installed")
            return False
            
        try:
            self.model_name = model_name
            model_path = self.config.get_models_dir() / model_name
            
            if not model_path.exists():
                raise FileNotFoundError(f"Model {model_name} not found at {model_path}")
            
            logger.info(f"Loading model {model_name} from {model_path}")
            
            # Check if it's a placeholder model
            readme_path = model_path / "README.md"
            if readme_path.exists():
                with open(readme_path, 'r') as f:
                    content = f.read()
                    if "Placeholder" in content:
                        logger.warning("This is a placeholder model. Install the required dependencies to use real models.")
                        return False
            
            # Set memory limits if specified
            if memory_limit is not None:
                logger.info(f"Setting memory limit to {memory_limit} MB")
                if hasattr(self.device, 'type') and self.device.type == "cuda":
                    # GPU memory limit
                    torch.cuda.set_per_process_memory_fraction(memory_limit / (torch.cuda.get_device_properties(0).total_memory / (1024 * 1024)))
                else:
                    # CPU memory limit - just log as we handle this differently
                    logger.info(f"Memory limit for CPU: {memory_limit} MB")
            
            # Determine if we can use ONNX
            use_onnx = self.config.get("use_onnx", True) and ONNX_AVAILABLE
            onnx_path = model_path / "model.onnx"
            
            if use_onnx and onnx_path.exists():
                logger.info("Using ONNX Runtime for inference")
                self.tokenizer = AutoTokenizer.from_pretrained(
                    model_path, 
                    use_fast=True
                )
                
                # Configure ONNX Runtime session
                sess_options = ort.SessionOptions()
                if memory_limit is not None:
                    # Set memory limit for ONNX
                    sess_options.set_memory_pattern(False)
                    sess_options.enable_mem_pattern = False
                    if hasattr(sess_options, 'set_memory_limit'):
                        sess_options.set_memory_limit(memory_limit)
                
                # Set number of threads based on available CPU cores
                cpu_count = psutil.cpu_count(logical=False) or 2
                sess_options.intra_op_num_threads = max(1, cpu_count - 1)
                
                providers = ['CPUExecutionProvider']
                self.onnx_session = ort.InferenceSession(
                    str(onnx_path), 
                    sess_options=sess_options, 
                    providers=providers
                )
                
                logger.info("ONNX model loaded successfully")
            else:
                # Use standard PyTorch loading
                self.tokenizer = AutoTokenizer.from_pretrained(
                    model_path, 
                    use_fast=True
                )
                
                # Load in 8-bit if possible to save memory
                try:
                    # Try to import bitsandbytes for 8-bit loading
                    try:
                        import bitsandbytes as bnb
                        has_bitsandbytes = True
                    except ImportError:
                        has_bitsandbytes = False
                    
                    if has_bitsandbytes:
                        logger.info("Loading model in 8-bit precision")
                        self.model = AutoModelForCausalLM.from_pretrained(
                            model_path,
                            device_map=self.device,
                            load_in_8bit=True,
                            torch_dtype=torch.float16 if hasattr(self.device, 'type') and self.device.type == "cuda" else torch.float32,
                            low_cpu_mem_usage=True
                        )
                    else:
                        logger.info(f"Loading model in standard precision on {self.device}")
                        self.model = AutoModelForCausalLM.from_pretrained(
                            model_path,
                            device_map="auto",
                            torch_dtype="auto",
                            low_cpu_mem_usage=True
                        )
                except Exception as e:
                    logger.warning(f"Could not load with optimizations: {e}")
                    logger.info("Falling back to standard loading")
                    
                    self.model = AutoModelForCausalLM.from_pretrained(
                        model_path,
                        low_cpu_mem_usage=True
                    )
                    
                    # Move to device manually if needed
                    if hasattr(self.device, 'type') and self.device.type != "cpu":
                        self.model = self.model.to(self.device)
                
                logger.info("Model loaded successfully")
            
            return True
        
        except Exception as e:
            logger.error(f"Error loading model: {e}")
            self.unload_model()
            return False
    
    def unload_model(self):
        """Unload the model and free memory."""
        logger.info("Unloading model")
        
        if self.onnx_session:
            del self.onnx_session
            self.onnx_session = None
        
        if self.model:
            del self.model
            self.model = None
        
        if self.tokenizer:
            del self.tokenizer
            self.tokenizer = None
        
        # Force garbage collection
        gc.collect()
        
        # Free CUDA memory if available
        if HAVE_TORCH and hasattr(self.device, 'type') and self.device.type == "cuda":
            torch.cuda.empty_cache()
        
        logger.info("Model unloaded")
    
    def generate(self, prompt: str, generation_config: Dict[str, Any]) -> str:
        """
        Generate text based on the prompt.
        
        Args:
            prompt: The input prompt
            generation_config: Configuration for text generation
            
        Returns:
            Generated text
        """
        if not HAVE_TRANSFORMERS:
            return "Error: transformers package is not installed"
            
        if not HAVE_TORCH:
            return "Error: torch package is not installed"
            
        if not self.tokenizer:
            return "Error: Model not loaded. Call load_model first."
        
        try:
            # Create generation config
            gen_config = GenerationConfig(
                temperature=generation_config.get("temperature", 0.7),
                max_length=generation_config.get("max_length", 1024),
                top_p=generation_config.get("top_p", 0.9),
                top_k=generation_config.get("top_k", 40),
                repetition_penalty=generation_config.get("repetition_penalty", 1.1),
                do_sample=generation_config.get("temperature", 0.7) > 0,
            )
            
            # Prepare input tokens
            inputs = self.tokenizer(prompt, return_tensors="pt")
            input_ids = inputs["input_ids"]
            
            if self.onnx_session:
                # ONNX inference
                outputs = self._generate_with_onnx(input_ids, gen_config)
            else:
                # Move inputs to the right device
                input_ids = input_ids.to(self.device)
                
                # Generate with PyTorch model
                with torch.no_grad():
                    outputs = self.model.generate(
                        input_ids,
                        generation_config=gen_config,
                        return_dict_in_generate=True,
                        output_scores=False
                    )
                
                # Get generation sequence
                generated_sequence = outputs.sequences[0]
                
                # Remove the input tokens to get only the generated part
                generated_sequence = generated_sequence[input_ids.shape[1]:]
            
                # Decode to text
                outputs = self.tokenizer.decode(generated_sequence, skip_special_tokens=True)
            
            return outputs
            
        except Exception as e:
            logger.error(f"Error during generation: {e}")
            return f"Error during generation: {str(e)}"
    
    def _generate_with_onnx(self, input_ids, gen_config) -> str:
        """Generate text using ONNX Runtime."""
        if not ONNX_AVAILABLE:
            return "Error: ONNX Runtime is not installed"
            
        if not HAVE_TORCH:
            return "Error: torch package is not installed"
            
        # Import numpy here to avoid dependency issues
        try:
            import numpy as np
        except ImportError:
            return "Error: numpy package is not installed"
            
        try:
            # Get input and output names
            input_name = self.onnx_session.get_inputs()[0].name
            output_name = self.onnx_session.get_outputs()[0].name
            
            # Convert to numpy for ONNX
            input_array = input_ids.cpu().numpy()
            
            # Initial input
            current_input = input_array
            
            # Generate tokens one by one
            generated_tokens = input_array.tolist()[0]
            
            for _ in range(gen_config.max_length - len(input_array[0])):
                # Run inference for next token
                outputs = self.onnx_session.run(
                    [output_name],
                    {input_name: current_input}
                )
                
                # Get logits for the last token
                next_token_logits = outputs[0][0, -1, :]
                
                # Apply temperature, top-k, top-p sampling
                if gen_config.do_sample:
                    # Apply temperature
                    next_token_logits = next_token_logits / gen_config.temperature
                    
                    # Apply top-k sampling
                    if gen_config.top_k > 0:
                        indices_to_remove = next_token_logits < torch.topk(
                            torch.tensor(next_token_logits), gen_config.top_k
                        )[0][..., -1, None]
                        next_token_logits[indices_to_remove] = float('-inf')
                    
                    # Apply top-p sampling
                    if gen_config.top_p < 1.0:
                        sorted_logits, sorted_indices = torch.sort(
                            torch.tensor(next_token_logits), descending=True
                        )
                        cumulative_probs = torch.cumsum(
                            torch.nn.functional.softmax(sorted_logits, dim=-1), dim=-1
                        )
                        
                        # Remove tokens with cumulative probability above the threshold
                        sorted_indices_to_remove = cumulative_probs > gen_config.top_p
                        # Shift the indices to the right to keep also the first token above the threshold
                        sorted_indices_to_remove[..., 1:] = sorted_indices_to_remove[..., :-1].clone()
                        sorted_indices_to_remove[..., 0] = 0
                        
                        # Create a mask for indices to remove
                        indices_to_remove = sorted_indices[sorted_indices_to_remove]
                        next_token_logits[indices_to_remove] = float('-inf')
                    
                    # Convert to probabilities and sample
                    probs = torch.nn.functional.softmax(torch.tensor(next_token_logits), dim=-1)
                    next_token = torch.multinomial(probs, num_samples=1).item()
                else:
                    # Greedy decoding
                    next_token = int(np.argmax(next_token_logits))
                
                # Check for EOS token
                if next_token in self.tokenizer.eos_token_id:
                    break
                
                # Add the predicted token to the generated sequence
                generated_tokens.append(next_token)
                
                # Update input for next iteration (only keep the last context_length tokens)
                current_input = np.array([generated_tokens[-512:]])
            
            # Decode the generated tokens
            generated_text = self.tokenizer.decode(generated_tokens[len(input_array[0]):], skip_special_tokens=True)
            
            return generated_text
            
        except Exception as e:
            logger.error(f"Error in ONNX generation: {e}")
            return f"Error in ONNX generation: {str(e)}"
