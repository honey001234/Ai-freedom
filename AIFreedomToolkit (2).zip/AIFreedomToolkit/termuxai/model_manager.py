import os
import json
import shutil
import logging
import datetime
from pathlib import Path
from typing import List, Dict, Any, Optional, Union

from .config import Config

# Handle optional dependencies
try:
    import torch
    HAVE_TORCH = True
except ImportError:
    HAVE_TORCH = False

try:
    from transformers import AutoModelForCausalLM, AutoTokenizer
    HAVE_TRANSFORMERS = True
except ImportError:
    HAVE_TRANSFORMERS = False

logger = logging.getLogger(__name__)

class ModelManager:
    """Manages downloaded AI models."""
    
    def __init__(self, config: Config):
        self.config = config
        self.models_dir = config.get_models_dir()
        os.makedirs(self.models_dir, exist_ok=True)
    
    def list_downloaded_models(self) -> List[Dict[str, str]]:
        """
        List all downloaded models.
        
        Returns:
            List of dictionaries with model information
        """
        models = []
        
        try:
            # Iterate through all directories in the models directory
            for model_dir in self.models_dir.iterdir():
                if not model_dir.is_dir():
                    continue
                
                # Get basic information
                model_name = model_dir.name
                
                # Get creation time
                try:
                    creation_time = datetime.datetime.fromtimestamp(
                        model_dir.stat().st_ctime
                    ).strftime("%Y-%m-%d %H:%M:%S")
                except Exception:
                    creation_time = "Unknown"
                
                # Get model size
                try:
                    size_bytes = sum(f.stat().st_size for f in model_dir.glob('**/*') if f.is_file())
                    size_str = self._format_size(size_bytes)
                except Exception:
                    size_str = "Unknown"
                
                # Try to determine model type
                model_type = self._determine_model_type(model_dir)
                
                models.append({
                    "name": model_name,
                    "size": size_str,
                    "date": creation_time,
                    "type": model_type
                })
        
        except Exception as e:
            logger.error(f"Error listing models: {e}")
        
        return models
    
    def _determine_model_type(self, model_dir: Path) -> str:
        """Determine the type of model based on available files."""
        # Check for config.json to get model type
        config_path = model_dir / "config.json"
        if config_path.exists():
            try:
                with open(config_path, 'r') as f:
                    config = json.load(f)
                
                # Extract model type information
                model_type = config.get("model_type", "")
                if model_type:
                    return model_type.upper()
            except Exception:
                pass
        
        # Check for common files that indicate model type
        if (model_dir / "pytorch_model.bin").exists() or (model_dir / "model.safetensors").exists():
            return "PyTorch"
        elif (model_dir / "model.onnx").exists():
            return "ONNX"
        elif (model_dir / "tokenizer.json").exists() and not (model_dir / "pytorch_model.bin").exists():
            return "Tokenizer Only"
        
        # Fallback
        return "Unknown"
    
    def _format_size(self, size_bytes: int) -> str:
        """Format size in bytes to human-readable format."""
        for unit in ["B", "KB", "MB", "GB", "TB"]:
            if size_bytes < 1024:
                return f"{size_bytes:.2f} {unit}"
            size_bytes /= 1024
        return f"{size_bytes:.2f} PB"
    
    def is_model_downloaded(self, model_name: str) -> bool:
        """
        Check if a model is downloaded.
        
        Args:
            model_name: Name of the model to check
            
        Returns:
            True if the model is downloaded, False otherwise
        """
        model_path = self.models_dir / model_name
        return model_path.exists() and model_path.is_dir()
    
    def remove_model(self, model_name: str) -> bool:
        """
        Remove a downloaded model.
        
        Args:
            model_name: Name of the model to remove
            
        Returns:
            True if the model was successfully removed, False otherwise
        """
        try:
            model_path = self.models_dir / model_name
            
            if not model_path.exists():
                logger.warning(f"Model {model_name} does not exist at {model_path}")
                return False
            
            # Remove the model directory
            shutil.rmtree(model_path)
            logger.info(f"Removed model {model_name}")
            return True
        
        except Exception as e:
            logger.error(f"Error removing model {model_name}: {e}")
            return False
    
    def remove_all_models(self) -> bool:
        """
        Remove all downloaded models.
        
        Returns:
            True if all models were successfully removed, False otherwise
        """
        try:
            # Get all model directories
            model_dirs = [d for d in self.models_dir.iterdir() if d.is_dir()]
            
            if not model_dirs:
                logger.info("No models to remove")
                return True
            
            # Remove each model directory
            for model_dir in model_dirs:
                shutil.rmtree(model_dir)
                logger.info(f"Removed model {model_dir.name}")
            
            return True
        
        except Exception as e:
            logger.error(f"Error removing all models: {e}")
            return False
    
    def optimize_model(self, model_name: str, quantize: bool = True) -> bool:
        """
        Optimize a model for inference.
        
        Args:
            model_name: Name of the model to optimize
            quantize: Whether to quantize the model
            
        Returns:
            True if optimization was successful, False otherwise
        """
        # This is a placeholder for future implementation
        # Model optimization techniques would go here
        logger.warning("Model optimization not implemented yet")
        return False
        
    def combine_models(self, model_names: List[str], combined_name: str, 
                       weights: Optional[List[float]] = None, 
                       method: str = "weighted_average") -> bool:
        """
        Combine two or more models into a new merged model.
        
        Args:
            model_names: List of model names to combine
            combined_name: Name for the combined model
            weights: Optional list of weights for each model (must match length of model_names)
            method: Method to use for combining ('weighted_average', 'task_arithmetic', or 'layer_selective')
            
        Returns:
            True if combination was successful, False otherwise
        """
        try:
            # Validate inputs
            if len(model_names) < 2:
                logger.error("At least two models are required for combination")
                return False
                
            # Check if all models exist
            for model_name in model_names:
                if not self.is_model_downloaded(model_name):
                    logger.error(f"Model {model_name} does not exist")
                    return False
            
            # Create a directory for the combined model
            combined_path = self.models_dir / combined_name
            if combined_path.exists():
                logger.error(f"Model {combined_name} already exists")
                return False
                
            os.makedirs(combined_path, exist_ok=True)
            
            # Try importing required libraries
            try:
                import torch
                import shutil
                from transformers import AutoModelForCausalLM, AutoTokenizer
                HAVE_REQUIREMENTS = True
            except ImportError:
                HAVE_REQUIREMENTS = False
                
            if not HAVE_REQUIREMENTS:
                # Create a placeholder model if dependencies aren't available
                self._create_combination_placeholder(combined_path, model_names, method, weights)
                logger.warning("Created placeholder for combined model - missing required dependencies")
                return True
            
            # Default to equal weights if not provided
            if weights is None:
                weights = [1.0 / len(model_names)] * len(model_names)
            
            if len(weights) != len(model_names):
                logger.error("Number of weights must match number of models")
                return False
            
            # Normalize weights
            sum_weights = sum(weights)
            weights = [w / sum_weights for w in weights]
            
            # Load models
            models = []
            for model_name in model_names:
                model_path = self.models_dir / model_name
                try:
                    model = AutoModelForCausalLM.from_pretrained(model_path)
                    models.append(model)
                except Exception as e:
                    logger.error(f"Failed to load model {model_name}: {e}")
                    shutil.rmtree(combined_path)
                    return False
            
            # Choose combination method
            if method == "weighted_average":
                success = self._combine_weighted_average(models, weights, combined_path)
            elif method == "task_arithmetic":
                success = self._combine_task_arithmetic(models, weights, combined_path)
            elif method == "layer_selective":
                success = self._combine_layer_selective(models, weights, combined_path)
            else:
                logger.error(f"Unknown combination method: {method}")
                shutil.rmtree(combined_path)
                return False
                
            # Copy tokenizer from first model
            try:
                first_model_path = self.models_dir / model_names[0]
                tokenizer = AutoTokenizer.from_pretrained(first_model_path)
                tokenizer.save_pretrained(combined_path)
            except Exception as e:
                logger.error(f"Failed to copy tokenizer: {e}")
                shutil.rmtree(combined_path)
                return False
                
            # Create metadata file
            metadata = {
                "combined_from": model_names,
                "weights": weights,
                "method": method,
                "date_created": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            }
            
            try:
                with open(combined_path / "combination_metadata.json", 'w') as f:
                    json.dump(metadata, f, indent=2)
            except Exception as e:
                logger.error(f"Failed to create metadata: {e}")
                # Continue anyway, this is not critical
                
            return success
            
        except Exception as e:
            logger.error(f"Error combining models: {e}")
            # Clean up if there was an error
            if combined_path.exists():
                try:
                    shutil.rmtree(combined_path)
                except:
                    pass
            return False
    
    def _create_combination_placeholder(self, combined_path: Path, model_names: List[str], 
                                        method: str, weights: Optional[List[float]]) -> None:
        """Create a placeholder for the combined model when dependencies aren't available."""
        # Create README explaining this is a placeholder
        readme_content = f"""# Combined Model Placeholder

This is a placeholder for a combined model that would be created from:
{', '.join(model_names)}

Method: {method}
Weights: {weights if weights else 'Equal weights'}

To create the actual combined model, please install the required dependencies:
- torch
- transformers

Then recreate this combined model.
"""
        with open(combined_path / "README.md", 'w') as f:
            f.write(readme_content)
            
        # Create metadata
        metadata = {
            "combined_from": model_names,
            "weights": weights if weights else [1.0 / len(model_names)] * len(model_names),
            "method": method,
            "is_placeholder": True,
            "date_created": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        
        with open(combined_path / "combination_metadata.json", 'w') as f:
            json.dump(metadata, f, indent=2)
    
    def _combine_weighted_average(self, models: List[Any], weights: List[float], 
                                 output_path: Path) -> bool:
        """Combine models using weighted average of parameters."""
        try:
            # Use the first model as the base
            combined_model = models[0]
            combined_dict = combined_model.state_dict()
            
            # For each parameter in the model
            for key in combined_dict.keys():
                # Reset the parameter to zero
                combined_dict[key] = torch.zeros_like(combined_dict[key])
                
                # Add the weighted contribution from each model
                for i, model in enumerate(models):
                    if key in model.state_dict():
                        param = model.state_dict()[key]
                        # Check if shapes match
                        if param.shape == combined_dict[key].shape:
                            combined_dict[key] += weights[i] * param
                        else:
                            logger.warning(f"Shape mismatch for parameter {key}, skipping")
            
            # Load the combined parameters into the model
            combined_model.load_state_dict(combined_dict)
            
            # Save the combined model
            combined_model.save_pretrained(output_path)
            
            return True
            
        except Exception as e:
            logger.error(f"Error in weighted average combination: {e}")
            return False
    
    def _combine_task_arithmetic(self, models: List[Any], weights: List[float], 
                                output_path: Path) -> bool:
        """
        Combine models using task arithmetic (adding weighted differences).
        This method is inspired by the concept of "model soups" and task vectors.
        """
        try:
            # Use the first model as the base
            base_model = models[0]
            base_dict = base_model.state_dict()
            combined_dict = base_model.state_dict().copy()
            
            # For each subsequent model, add its weighted difference from the base
            for i in range(1, len(models)):
                model = models[i]
                weight = weights[i]
                
                for key in combined_dict.keys():
                    if key in model.state_dict():
                        # Get parameters
                        base_param = base_dict[key]
                        model_param = model.state_dict()[key]
                        
                        # Check if shapes match
                        if model_param.shape == base_param.shape:
                            # Add weighted difference (task vector * weight)
                            combined_dict[key] = combined_dict[key] + weight * (model_param - base_param)
                        else:
                            logger.warning(f"Shape mismatch for parameter {key}, skipping")
            
            # Load the combined parameters into the base model
            base_model.load_state_dict(combined_dict)
            
            # Save the combined model
            base_model.save_pretrained(output_path)
            
            return True
            
        except Exception as e:
            logger.error(f"Error in task arithmetic combination: {e}")
            return False
    
    def _combine_layer_selective(self, models: List[Any], weights: List[float], 
                                output_path: Path) -> bool:
        """
        Combine models by selectively using layers from different models.
        This method uses different layers from different models based on their position.
        """
        try:
            # Use the first model as the base
            combined_model = models[0]
            combined_dict = combined_model.state_dict().copy()
            
            # Identify layer groups based on naming patterns
            layer_groups = {}
            for key in combined_dict.keys():
                # Find layer number (assuming format like 'layers.12.attention' etc.)
                parts = key.split('.')
                layer_num = None
                for i, part in enumerate(parts):
                    if part.isdigit() and i+1 < len(parts) and parts[i+1] in ['attention', 'mlp', 'ffn', 'feed_forward', 'self_attn']:
                        layer_num = int(part)
                        break
                
                if layer_num is not None:
                    if layer_num not in layer_groups:
                        layer_groups[layer_num] = []
                    layer_groups[layer_num].append(key)
            
            # Distribute layers based on weights
            num_layers = max(layer_groups.keys()) + 1 if layer_groups else 0
            if num_layers > 0:
                # Create ranges of layers for each model
                layer_boundaries = [0]
                running_sum = 0
                for w in weights[:-1]:  # All but the last weight
                    running_sum += w
                    layer_boundaries.append(int(running_sum * num_layers))
                layer_boundaries.append(num_layers)  # Last boundary
                
                # For each layer group, decide which model to use
                for layer_num in range(num_layers):
                    model_idx = 0
                    for i in range(len(layer_boundaries) - 1):
                        if layer_boundaries[i] <= layer_num < layer_boundaries[i+1]:
                            model_idx = i
                            break
                    
                    # Copy parameters from the selected model for this layer
                    if layer_num in layer_groups:
                        model = models[model_idx]
                        for key in layer_groups[layer_num]:
                            if key in model.state_dict():
                                combined_dict[key] = model.state_dict()[key].clone()
            
            # Load the combined parameters into the model
            combined_model.load_state_dict(combined_dict)
            
            # Save the combined model
            combined_model.save_pretrained(output_path)
            
            return True
            
        except Exception as e:
            logger.error(f"Error in layer selective combination: {e}")
            return False
