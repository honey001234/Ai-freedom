import os
import sys
import logging
import platform
import psutil
from typing import Optional, Tuple

logger = logging.getLogger(__name__)

def check_termux_environment() -> bool:
    """Check if the application is running in a Termux environment."""
    # Check for common Termux environment indicators
    if "com.termux" in os.environ.get("PREFIX", ""):
        return True
    
    if os.path.exists("/data/data/com.termux"):
        return True
    
    # Check for Android in platform
    if "android" in platform.platform().lower():
        return True
    
    return False

def get_available_memory() -> float:
    """
    Get available system memory in GB.
    
    Returns:
        Available memory in GB
    """
    try:
        mem_info = psutil.virtual_memory()
        return mem_info.available / (1024 ** 3)  # Convert to GB
    except Exception as e:
        logger.error(f"Error getting available memory: {e}")
        # Default to a conservative estimate
        return 2.0  # Assume 2GB available

def get_cpu_info() -> dict:
    """
    Get CPU information.
    
    Returns:
        Dictionary with CPU information
    """
    cpu_info = {
        "count": psutil.cpu_count(logical=False),
        "logical_count": psutil.cpu_count(logical=True),
        "percent": psutil.cpu_percent(interval=0.1),
    }
    
    return cpu_info

def set_logging_level(level):
    """Set the logging level for the application."""
    logger = logging.getLogger("termuxai")
    logger.setLevel(level)
    
    # Update all handlers
    for handler in logger.handlers:
        handler.setLevel(level)
    
    # If no handlers, add one
    if not logger.handlers:
        handler = logging.StreamHandler()
        handler.setLevel(level)
        formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
        handler.setFormatter(formatter)
        logger.addHandler(handler)

def check_dependencies() -> Tuple[bool, str]:
    """
    Check if all required dependencies are available.
    
    Returns:
        Tuple of (success, message)
    """
    missing = []
    
    # Core dependencies
    try:
        import torch
    except ImportError:
        missing.append("torch")
    
    try:
        import transformers
    except ImportError:
        missing.append("transformers")
    
    try:
        import huggingface_hub
    except ImportError:
        missing.append("huggingface_hub")
    
    # Optional but recommended
    recommended = []
    
    try:
        import onnxruntime
    except ImportError:
        recommended.append("onnxruntime")
    
    try:
        import bitsandbytes
    except ImportError:
        recommended.append("bitsandbytes")
    
    if missing:
        # Still return True but with a warning message about limited functionality
        warning_msg = f"Some features will be limited. Missing dependencies: {', '.join(missing)}"
        logger.warning(warning_msg)
        return True, warning_msg
    
    if recommended:
        return True, f"All required dependencies installed. Optional missing: {', '.join(recommended)}"
    
    return True, "All dependencies installed."

def optimize_torch_for_mobile():
    """Apply optimizations for running PyTorch on mobile devices."""
    try:
        import torch
        
        # Set number of threads based on available CPU cores
        # Leave one core free for the OS
        num_cores = max(1, psutil.cpu_count(logical=False) - 1)
        if hasattr(torch, 'set_num_threads'):
            torch.set_num_threads(num_cores)
        
        # Disable debug mode
        torch._C._debug_set_autodiff_subgraph_inlining(False)
        
        logger.info(f"PyTorch optimized for mobile with {num_cores} threads")
        return True
    except Exception as e:
        logger.error(f"Failed to optimize PyTorch: {e}")
        return False
